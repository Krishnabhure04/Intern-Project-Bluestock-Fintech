import React from "react";
import IPOForm from "./components/IPOForm";

function App() {
  return (
    <div className="min-h-screen bg-gray-100 p-4">
      <IPOForm />
    </div>
  );
}

export default App;