import React, { useState } from "react";
import axios from "axios";

const IPOForm = () => {
  const [formData, setFormData] = useState({
    companyName: "",
    priceBand: "",
    lotSize: "",
    openDate: "",
    closeDate: "",
    sector: "",
    status: "Upcoming",
  });

  const [errors, setErrors] = useState({});
  const [success, setSuccess] = useState("");

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
    setErrors({});
    setSuccess("");
  };

  const validate = () => {
    const newErrors = {};
    const { companyName, priceBand, lotSize, openDate, closeDate, sector } = formData;

    if (!companyName) newErrors.companyName = "Company name is required";
    if (!priceBand || isNaN(priceBand)) newErrors.priceBand = "Enter valid price";
    if (!lotSize || isNaN(lotSize)) newErrors.lotSize = "Enter valid lot size";
    if (!openDate) newErrors.openDate = "Open date is required";
    if (!closeDate) newErrors.closeDate = "Close date is required";
    if (new Date(openDate) >= new Date(closeDate)) newErrors.date = "Close date must be after open date";
    if (!sector) newErrors.sector = "Sector is required";

    return newErrors;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const validationErrors = validate();
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }

    try {
      await axios.post("https://jsonplaceholder.typicode.com/posts", formData);
      setSuccess("IPO details submitted successfully!");
      setFormData({
        companyName: "",
        priceBand: "",
        lotSize: "",
        openDate: "",
        closeDate: "",
        sector: "",
        status: "Upcoming",
      });
    } catch (error) {
      setErrors({ api: "Failed to submit IPO details" });
    }
  };

  return (
    <div className="max-w-3xl mx-auto p-6 bg-white rounded-xl shadow-md mt-10">
      <h2 className="text-2xl font-semibold mb-4 text-center">Add New IPO</h2>
      <form onSubmit={handleSubmit} className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label htmlFor="companyName">Company Name</label>
          <input
            type="text"
            name="companyName"
            value={formData.companyName}
            onChange={handleChange}
            className="w-full p-2 border rounded"
            aria-label="Company Name"
          />
          {errors.companyName && <p className="text-red-500 text-sm">{errors.companyName}</p>}
        </div>

        <div>
          <label htmlFor="priceBand">Price Band (₹)</label>
          <input
            type="text"
            name="priceBand"
            value={formData.priceBand}
            onChange={handleChange}
            className="w-full p-2 border rounded"
            aria-label="Price Band"
          />
          {errors.priceBand && <p className="text-red-500 text-sm">{errors.priceBand}</p>}
        </div>

        <div>
          <label htmlFor="lotSize">Lot Size</label>
          <input
            type="text"
            name="lotSize"
            value={formData.lotSize}
            onChange={handleChange}
            className="w-full p-2 border rounded"
            aria-label="Lot Size"
          />
          {errors.lotSize && <p className="text-red-500 text-sm">{errors.lotSize}</p>}
        </div>

        <div>
          <label htmlFor="sector">Sector</label>
          <input
            type="text"
            name="sector"
            value={formData.sector}
            onChange={handleChange}
            className="w-full p-2 border rounded"
            aria-label="Sector"
          />
          {errors.sector && <p className="text-red-500 text-sm">{errors.sector}</p>}
        </div>

        <div>
          <label htmlFor="openDate">Open Date</label>
          <input
            type="date"
            name="openDate"
            value={formData.openDate}
            onChange={handleChange}
            className="w-full p-2 border rounded"
            aria-label="Open Date"
          />
          {errors.openDate && <p className="text-red-500 text-sm">{errors.openDate}</p>}
        </div>

        <div>
          <label htmlFor="closeDate">Close Date</label>
          <input
            type="date"
            name="closeDate"
            value={formData.closeDate}
            onChange={handleChange}
            className="w-full p-2 border rounded"
            aria-label="Close Date"
          />
          {errors.closeDate && <p className="text-red-500 text-sm">{errors.closeDate}</p>}
        </div>

        <div className="sm:col-span-2">
          <label htmlFor="status">IPO Status</label>
          <select
            name="status"
            value={formData.status}
            onChange={handleChange}
            className="w-full p-2 border rounded"
            aria-label="IPO Status"
          >
            <option>Upcoming</option>
            <option>Closed</option>
            <option>Live</option>
          </select>
        </div>

        {errors.date && <p className="text-red-500 sm:col-span-2">{errors.date}</p>}
        {errors.api && <p className="text-red-500 sm:col-span-2">{errors.api}</p>}
        {success && <p className="text-green-600 sm:col-span-2">{success}</p>}

        <div className="sm:col-span-2 flex justify-end gap-4 mt-4">
          <button
            type="submit"
            className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
          >
            Submit
          </button>
          <button
            type="reset"
            className="bg-gray-300 px-4 py-2 rounded"
            onClick={() => {
              setFormData({
                companyName: "",
                priceBand: "",
                lotSize: "",
                openDate: "",
                closeDate: "",
                sector: "",
                status: "Upcoming",
              });
              setErrors({});
              setSuccess("");
            }}
          >
            Reset
          </button>
        </div>
      </form>
    </div>
  );
};

export default IPOForm;